# facebook-reaction
Simple app that auto react to someone posts on Facebook

# How-to

Edit main.js, replace `my_id`, `token` and `ids` with your informations, modify `react` with reactions you want.

Run `npm install` or `yarn install` to install dependencies

Run `node main.js` to start
